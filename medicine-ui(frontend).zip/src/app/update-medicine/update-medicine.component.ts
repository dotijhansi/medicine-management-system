import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-update-medicine',
  standalone: true,
  templateUrl: './update-medicine.component.html',
  styleUrls: ['./update-medicine.component.css'],
  imports: [CommonModule, ReactiveFormsModule]
})
export class UpdateMedicineComponent {
  updateMedicineForm: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.updateMedicineForm = this.fb.group({
      medicineId: ['', Validators.required],
      medicineName: ['', Validators.required],
      categoryId: ['', Validators.required],  // Added categoryId input
      categoryName: ['', Validators.required],
      price: ['', Validators.required],
      quantity: ['', Validators.required],
      expiryDate: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.updateMedicineForm.valid) {
      const formValues = this.updateMedicineForm.value;
      const token = localStorage.getItem('token');

      const medicineUpdatePayload = {
        medicineId: formValues.medicineId,
        medicineName: formValues.medicineName,
        categoryId: formValues.categoryId,  // Use user-entered categoryId
        category: {
          categoryId: formValues.categoryId,
          categoryName: formValues.categoryName
        },
        price: formValues.price,
        quantity: formValues.quantity,
        expiryDate: formValues.expiryDate,
        criticalStockLevel: 5
      };

      this.http.put(`https://localhost:7228/api/Medicines/${formValues.medicineId}`, medicineUpdatePayload, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }).subscribe({
        next: (response) => {
          console.log('Medicine updated successfully:', response);
          alert('Medicine updated successfully!');
          this.updateMedicineForm.reset();
        },
        error: (error) => {
          console.error('Error updating medicine:', error);
          alert('Failed to update medicine.');
        }
      });
    }
  }
}
