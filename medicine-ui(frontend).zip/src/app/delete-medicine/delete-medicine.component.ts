import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-delete-medicine',
  standalone: true,
  templateUrl: './delete-medicine.component.html',
  styleUrls: ['./delete-medicine.component.css'],
  imports: [CommonModule, ReactiveFormsModule]
})
export class DeleteMedicineComponent {
  deleteMedicineForm: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.deleteMedicineForm = this.fb.group({
      medicineId: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.deleteMedicineForm.valid) {
      const { medicineId } = this.deleteMedicineForm.value;
      const token = localStorage.getItem('token');

      this.http.delete(`https://localhost:7228/api/Medicines/${medicineId}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }).subscribe({
        next: (response) => {
          console.log('Medicine deleted successfully:', response);
          alert('Medicine deleted successfully!');
          this.deleteMedicineForm.reset();
        },
        error: (error) => {
          console.error('Error deleting medicine:', error);
          alert('Failed to delete medicine. Maybe ID not found.');
        }
      });
    }
  }
}
