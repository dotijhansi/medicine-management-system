import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-view-medicines',
  standalone: true,
  templateUrl: './view-medicines.component.html',
  styleUrls: ['./view-medicines.component.css'],
  imports: [CommonModule]
})
export class ViewMedicinesComponent implements OnInit {
  medicines: any[] = [];
  loading: boolean = false;
  errorMessage: string = '';

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.loadMedicines();
  }

  loadMedicines() {
    const token = localStorage.getItem('token');

    if (!token) {
      this.errorMessage = 'No token found. Please login again.';
      console.error(this.errorMessage);
      return;
    }

    this.loading = true;
    this.http.get<any[]>('https://localhost:7228/api/Medicines', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    }).subscribe({
      next: (response) => {
        console.log('Medicines loaded:', response);
        this.medicines = response;
        this.loading = false;
        if (this.medicines.length === 0) {
          this.errorMessage = 'No medicines found.';
        }
      },
      error: (error) => {
        this.loading = false;
        console.error('Error loading medicines:', error);
        this.errorMessage = 'Failed to load medicines.';
      }
    });
  }

  getExpiryStatus(expiryDateStr: string): string {
    const today = new Date();
    const expiryDate = new Date(expiryDateStr);
    const diffInTime = expiryDate.getTime() - today.getTime();
    const diffInDays = diffInTime / (1000 * 3600 * 24);

    if (diffInDays < 0) return 'expired';
    if (diffInDays <= 30) return 'expiring-soon';
    return 'safe';
  }
}
