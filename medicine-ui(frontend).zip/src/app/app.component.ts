import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';  // Important
import { CommonModule } from '@angular/common';  // Optional

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule],  // Important
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'medicine-ui';
}
