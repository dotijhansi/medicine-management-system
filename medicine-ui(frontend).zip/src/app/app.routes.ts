import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddMedicineComponent } from './add-medicine/add-medicine.component';
import { DeleteMedicineComponent } from './delete-medicine/delete-medicine.component';
import { UpdateMedicineComponent } from './update-medicine/update-medicine.component';
import { ViewMedicinesComponent } from './view-medicines/view-medicines.component';
import { AddCategoryComponent } from './add-category/add-category.component';
import { ViewCategoriesComponent } from './view-categories/view-categories.component';
import { SearchMedicinesComponent } from './search-medicines/search-medicines.component';

export const appRoutes: Routes = [
  { path: '', component: LoginComponent },         // Default login page
  { path: 'dashboard', component: DashboardComponent }, // Dashboard after login
  { path: 'add-medicine', component: AddMedicineComponent },   // Add medicine page
  { path: 'delete-medicine', component: DeleteMedicineComponent }, // Delete medicine page
  { path: 'update-medicine', component: UpdateMedicineComponent }, // Update medicine page
  { path: 'view-medicines', component: ViewMedicinesComponent },  // View medicines page
  { path: 'add-category', component: AddCategoryComponent },
  { path: 'view-categories', component: ViewCategoriesComponent },
  { path: 'search-medicines', component: SearchMedicinesComponent }

];




