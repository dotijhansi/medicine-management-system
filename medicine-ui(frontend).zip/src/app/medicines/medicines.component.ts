import { Component } from '@angular/core';

@Component({
  selector: 'app-medicines',
  imports: [],
  templateUrl: './medicines.component.html',
  styleUrl: './medicines.component.css'
})
export class MedicinesComponent {

}
