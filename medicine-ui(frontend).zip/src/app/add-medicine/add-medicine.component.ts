import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-add-medicine',
  standalone: true,
  templateUrl: './add-medicine.component.html',
  styleUrls: ['./add-medicine.component.css'],
  imports: [CommonModule, ReactiveFormsModule]
})
export class AddMedicineComponent {
  addMedicineForm: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.addMedicineForm = this.fb.group({
      medicineName: ['', Validators.required],
      categoryName: ['', Validators.required],
      price: ['', Validators.required],
      quantity: ['', Validators.required],
      expiryDate: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.addMedicineForm.valid) {
      const formData = this.addMedicineForm.value;

      // Prepare the request body as per backend API
      const medicineData = {
        medicineId: 0,  // New medicine
        medicineName: formData.medicineName,
        categoryId: 0,  // Will be created inside
        category: {
          categoryId: 0,
          categoryName: formData.categoryName
        },
        price: formData.price,
        quantity: formData.quantity,
        expiryDate: formData.expiryDate,
        criticalStockLevel: 5  // You can set default value
      };

      const token = localStorage.getItem('token'); // Fetch token

      this.http.post('https://localhost:7228/api/Medicines', medicineData, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }).subscribe({
        next: (response) => {
          console.log('Medicine added successfully:', response);
          alert('Medicine added successfully!');
          this.addMedicineForm.reset(); // Clear the form after success
        },
        error: (error) => {
          console.error('Error adding medicine:', error);
          alert('Failed to add medicine.');
        }
      });
    }
  }
}
