import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-search-medicines',
  standalone: true,
  templateUrl: './search-medicines.component.html',
  styleUrls: ['./search-medicines.component.css'],
  imports: [CommonModule, ReactiveFormsModule]
})
export class SearchMedicinesComponent {
  searchForm: FormGroup;
  medicines: any[] = [];
  singleMedicine: any = null;
  message: string = '';
  token: string | null = '';

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.token = localStorage.getItem('token');
    this.searchForm = this.fb.group({
      id: [''],
      category: ['']
    });
  }

  searchById() {
    const id = this.searchForm.get('id')?.value;
    this.http.get(`https://localhost:7228/api/Medicines/SearchById/${id}`, {
      headers: { Authorization: `Bearer ${this.token}` }
    }).subscribe({
      next: (res) => {
        this.singleMedicine = res;
        this.medicines = [];
        this.message = '';
      },
      error: () => {
        this.message = 'No medicine found with this ID.';
        this.singleMedicine = null;
      }
    });
  }

  searchByCategory() {
    const category = this.searchForm.get('category')?.value;
    this.http.get<any[]>(`https://localhost:7228/api/Medicines/SearchByCategory?categoryName=${category}`, {
      headers: { Authorization: `Bearer ${this.token}` }
    }).subscribe({
      next: (res) => {
        this.medicines = res;
        this.singleMedicine = null;
        this.message = res.length === 0 ? 'No medicines found in this category.' : '';
      },
      error: () => {
        this.message = 'Error fetching data.';
      }
    });
  }

  fetchExpiringNextMonth() {
    this.http.get<any[]>('https://localhost:7228/api/Medicines/ExpiringNextMonth', {
      headers: { Authorization: `Bearer ${this.token}` }
    }).subscribe(res => {
      this.medicines = res;
      this.singleMedicine = null;
      this.message = res.length === 0 ? 'No medicines expiring next month.' : '';
    });
  }

  fetchCriticalStock() {
    this.http.get<any[]>('https://localhost:7228/api/Medicines/CriticalStock', {
      headers: { Authorization: `Bearer ${this.token}` }
    }).subscribe(res => {
      this.medicines = res;
      this.singleMedicine = null;
      this.message = res.length === 0 ? 'No medicines in critical stock.' : '';
    });
  }
}
