// app.config.ts
import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';

export const appRoutes: Routes = [
  { path: '', component: LoginComponent },  // Default route
  { path: 'login', component: LoginComponent },
];
