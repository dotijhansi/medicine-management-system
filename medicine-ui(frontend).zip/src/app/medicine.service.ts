import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MedicineService {

  // The base URL for the API
  private apiUrl = 'https://localhost:7228/api/Medicines';

  // Inject HttpClient
  constructor(private http: HttpClient) { }

  // Method to fetch all medicines
  getMedicines(): Observable<any> {
    // Get the token from local storage (after login)
    const token = localStorage.getItem('token');

    // Set the Authorization header with the token
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

    return this.http.get<any>(this.apiUrl, { headers });
  }
}
