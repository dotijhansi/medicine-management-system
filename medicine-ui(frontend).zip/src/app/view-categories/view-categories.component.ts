import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-view-categories',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './view-categories.component.html',
  styleUrls: ['./view-categories.component.css']
})
export class ViewCategoriesComponent implements OnInit {
  categories: any[] = [];

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    const token = localStorage.getItem('token');

    this.http.get<any[]>('https://localhost:7228/api/Categories', {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: res => {
        this.categories = res;
      },
      error: err => {
        alert('Failed to load categories');
        console.error(err);
      }
    });
  }
}
