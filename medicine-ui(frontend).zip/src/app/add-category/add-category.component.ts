import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-add-category',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent {
  addCategoryForm: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.addCategoryForm = this.fb.group({
      categoryName: ['', Validators.required]
    });
  }

  onSubmit() {
    const token = localStorage.getItem('token');
    const category = this.addCategoryForm.value;

    this.http.post('https://localhost:7228/api/Categories', category, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: res => {
        alert('Category added successfully!');
        this.addCategoryForm.reset();
      },
      error: err => {
        alert('Failed to add category.');
        console.error(err);
      }
    });
  }
}
