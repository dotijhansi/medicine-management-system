import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';  // Make sure the path is correct
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';      // <--- ADD THIS
import { appRoutes } from './app/app.routes';          // <--- ADD THIS

bootstrapApplication(AppComponent, {
  providers: [
    provideHttpClient(),
    provideRouter(appRoutes)  // <--- ADD THIS for Routing
  ]
}).catch(err => console.error(err));
