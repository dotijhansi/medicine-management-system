﻿using Microsoft.EntityFrameworkCore;
using MedicineInventory.Models; // We will create this Models folder soon!

namespace MedicineInventory.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Operator> Operators { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Medicine> Medicines { get; set; }
    }
}
