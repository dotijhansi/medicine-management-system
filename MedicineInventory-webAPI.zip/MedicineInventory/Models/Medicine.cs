﻿namespace MedicineInventory.Models
{
    public class Medicine
    {
        public int MedicineId { get; set; }
        public string MedicineName { get; set; }
        public int CategoryId { get; set; }
        public Category Category { get; set; }  // Navigation property
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public DateTime ExpiryDate { get; set; }
        public int CriticalStockLevel { get; set; }
    }
}
