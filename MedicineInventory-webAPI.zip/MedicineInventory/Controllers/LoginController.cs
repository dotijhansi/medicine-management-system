﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;

namespace MedicineInventory.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public LoginController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [AllowAnonymous]  // Allows unauthenticated users to access this action
        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            // For testing: Hardcoded username/password. Later connect with DB.
            if (username == "bhanu" && password == "bhanu123")
            {
                var claims = new[]
                {
                    new Claim(ClaimTypes.Name, username)
                };

                // Secret key for signing JWT. Make sure it's secure and stored properly (e.g., in environment variables).
                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("JhansiYamunaMedicineInventoryKey@123!"));
                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                // Generate the token
                var token = new JwtSecurityToken(
                    issuer: "MedicineInventory",  // Issuer can be the application or domain name
                    audience: "MedicineInventoryClient", // Audience can be the client or your app
                    claims: claims,
                    expires: DateTime.Now.AddMinutes(30), // Set the token expiration time
                    signingCredentials: creds);

                // Return the generated JWT token to the client
                return Ok(new
                {
                    token = new JwtSecurityTokenHandler().WriteToken(token)
                });
            }

            return Unauthorized("Invalid credentials");
        }
    }
}
