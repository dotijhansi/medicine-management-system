﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MedicineInventory.Data;
using MedicineInventory.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MedicineInventory.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MedicinesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public MedicinesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Medicines
        [HttpGet]
        [Authorize]
        public async Task<ActionResult<IEnumerable<Medicine>>> GetMedicines()
        {
            return await _context.Medicines.Include(m => m.Category).ToListAsync();
        }

        // GET: api/Medicines/5
        [HttpGet("{id}")]
        [Authorize]
        public async Task<ActionResult<Medicine>> GetMedicine(int id)
        {
            var medicine = await _context.Medicines.Include(m => m.Category)
                                                    .FirstOrDefaultAsync(m => m.MedicineId == id);

            if (medicine == null)
            {
                return NotFound();
            }

            return medicine;
        }

        // POST: api/Medicines
        [HttpPost]
        [Authorize]
        public async Task<ActionResult<Medicine>> PostMedicine(Medicine medicine)
        {
            // Check if category already exists
            if (medicine.Category != null && !string.IsNullOrWhiteSpace(medicine.Category.CategoryName))
            {
                var existingCategory = await _context.Categories
                    .FirstOrDefaultAsync(c => c.CategoryName.ToLower() == medicine.Category.CategoryName.ToLower());

                if (existingCategory != null)
                {
                    medicine.Category = existingCategory;
                }
            }

            _context.Medicines.Add(medicine);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetMedicine), new { id = medicine.MedicineId }, medicine);
        }

        // PUT: api/Medicines/5
        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> PutMedicine(int id, Medicine medicine)
        {
            if (id != medicine.MedicineId)
            {
                return BadRequest();
            }

            // Attach existing category if name already exists
            if (medicine.Category != null && !string.IsNullOrWhiteSpace(medicine.Category.CategoryName))
            {
                var existingCategory = await _context.Categories
                    .FirstOrDefaultAsync(c => c.CategoryName.ToLower() == medicine.Category.CategoryName.ToLower());

                if (existingCategory != null)
                {
                    medicine.Category = existingCategory;
                }
            }

            _context.Entry(medicine).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                return BadRequest("Update failed. Check data consistency. Error: " + ex.Message);
            }

            return NoContent();
        }

        // DELETE: api/Medicines/5
        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteMedicine(int id)
        {
            var medicine = await _context.Medicines.FindAsync(id);
            if (medicine == null)
            {
                return NotFound();
            }

            _context.Medicines.Remove(medicine);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // -------------------------------
        // ✅ STEP 4 - Search APIs Below
        // -------------------------------

        // GET: api/Medicines/SearchByCategory?categoryName=Antibiotic
        [HttpGet("SearchByCategory")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<Medicine>>> SearchByCategory(string categoryName)
        {
            var medicines = await _context.Medicines
                .Include(m => m.Category)
                .Where(m => m.Category.CategoryName.ToLower() == categoryName.ToLower())
                .ToListAsync();

            return Ok(medicines);
        }

        // GET: api/Medicines/ExpiringNextMonth
        [HttpGet("ExpiringNextMonth")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<Medicine>>> ExpiringNextMonth()
        {
            var today = DateTime.Today;
            var nextMonth = today.AddMonths(1);

            var medicines = await _context.Medicines
                .Include(m => m.Category)
                .Where(m => m.ExpiryDate.Month == nextMonth.Month && m.ExpiryDate.Year == nextMonth.Year)
                .ToListAsync();

            return Ok(medicines);
        }

        // GET: api/Medicines/CriticalStock
        [HttpGet("CriticalStock")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<Medicine>>> CriticalStock()
        {
            var medicines = await _context.Medicines
                .Include(m => m.Category)
                .Where(m => m.Quantity <= m.CriticalStockLevel)
                .ToListAsync();

            return Ok(medicines);
        }
    }
}
